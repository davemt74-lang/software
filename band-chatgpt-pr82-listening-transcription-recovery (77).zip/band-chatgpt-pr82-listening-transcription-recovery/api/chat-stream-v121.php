<?php
declare(strict_types=1);
require dirname(__DIR__).'/includes/bootstrap.php';
require_once dirname(__DIR__).'/includes/ai-stream-v121.php';

header('Content-Type: application/x-ndjson; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Accel-Buffering: no');
@ini_set('zlib.output_compression','0');
@ini_set('output_buffering','0');
@set_time_limit(180);
ignore_user_abort(true);

function chat_v121_emit(array $event): void {
    if(connection_aborted())return;
    if(function_exists('agent_runtime_v125_trace_id')&&!isset($event['trace_id']))$event['trace_id']=agent_runtime_v125_trace_id();
    echo json_encode($event,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
    if(function_exists('ob_flush'))@ob_flush();
    flush();
}
function chat_v121_owned(PDO $pdo,int $conversationId,int $userId): bool {
    if($conversationId<1)return false;
    $stmt=$pdo->prepare('SELECT id FROM chat_conversations WHERE id=? AND user_id=? LIMIT 1');$stmt->execute([$conversationId,$userId]);
    return (bool)$stmt->fetchColumn();
}
function chat_v121_context(string $query,array $user,array $agentContext=[]): array {
    $context=chat_context($query,$user);
    if($agentContext&&function_exists('agent_surface_v131_context_item'))array_unshift($context,agent_surface_v131_context_item($agentContext));
    if(release_v105_schema_ready()&&permission_v105_has('release.manage',$user)){
        $releaseContext=release_v105_agent_context($user,release_v105_chat_intent($query)?10:4);
        if($releaseContext)$context=array_merge($releaseContext,$context);
        else{
            $resourceLines=[];
            foreach(array_slice(release_v105_resources($user,20),0,12) as $resource){
                $resourceLines[]='Resource #'.(int)$resource['id'].' · '.(string)$resource['resource_type'].' · '.(string)$resource['title'].((string)$resource['provider_key']!==''?' · provider '.(string)$resource['provider_key']:'');
            }
            foreach(release_v105_integrations($user) as $integration){
                $resourceLines[]='Integration '.(string)$integration['provider_key'].' · '.(string)$integration['status'].' · '.((string)$integration['label']?: (string)$integration['connection_key']);
            }
            if($resourceLines)$context[]=['source'=>'agent-brain:operations-resources','title'=>'Agent Operations resources and connected capabilities','text'=>implode("\n",$resourceLines)];
        }
        $context[]=['source'=>'agent:release-operations-tool','title'=>'Agent Operations tool contract','text'=>'Release Calendar is a first-class Agent Brain tool even before the first release is created. It coordinates release plans, due work, tracks, shows, resources, contact lists, documents, websites and audited external actions. External actions may require approval before side effects. Never claim an external action was sent unless its action record reports completion.'];
    }
    if(release_v105_schema_ready()&&preg_match('/\b(credit|credits|credited|contributor|producer|songwriter|engineer)\b/i',$query)){
        $track=agent_tool_find_track($query,$user);
        if($track&&permission_v105_track_allowed($track,$user)){
            $rows=credits_v105_rows($user,(int)$track['id']);$lines=[];
            foreach($rows as $row)$lines[]=(string)$row['display_name'].' · '.(string)$row['contribution_role'].(trim((string)$row['contribution_detail'])!==''?' · '.(string)$row['contribution_detail']:'');
            if($lines)$context[]=['source'=>'agent-brain:credits:'.(int)$track['id'],'title'=>'Credits graph · '.(string)$track['title'],'text'=>implode("\n",$lines)];
        }
    }
    return array_slice($context,0,32);
}

$assistantMessageId=0;$conversationId=0;$pdo=null;$idempotencyScope='';$idempotencyKey='';$idempotencyClaimed=false;
try{
    $user=current_user();$pdo=db();
    if(!$user||!has_permission('chat.access',$user))throw new RuntimeException('Chat access is not available for this account.');
    if(!$pdo||!table_exists('chat_conversations')||!table_exists('chat_messages'))throw new RuntimeException('Chat storage is not ready.');

    $input=json_decode((string)file_get_contents('php://input'),true);if(!is_array($input))$input=$_POST;
    $csrf=(string)($input['csrf_token']??'');if($csrf===''||!hash_equals(csrf_token(),$csrf))throw new RuntimeException('Session expired. Refresh the page and try again.');
    $query=trim((string)($input['message']??''));if($query==='')throw new RuntimeException('Enter a message.');if(mb_strlen($query)>6000)throw new RuntimeException('That message is too long.');
    $userId=(int)$user['id'];$conversationId=max(0,(int)($input['conversation_id']??0));
    $idempotencyKey=mb_substr(trim((string)($input['idempotency_key']??'')),0,160);$idempotencyScope='voice-chat:user-'.$userId;
    if($idempotencyKey!==''){
        $claim=agent_runtime_v125_idempotency_claim($idempotencyScope,$idempotencyKey,86400);
        if(empty($claim['claimed'])){
            if(($claim['state']??'')==='completed'&&is_array($claim['result']??null)){
                $replay=$claim['result'];agent_runtime_v125_trace('chat.idempotency.replay',['user_id'=>$userId,'conversation_id'=>(int)($replay['conversation_id']??0),'ok'=>!empty($replay['ok'])]);
                if(empty($replay['ok'])){chat_v121_emit(['type'=>'error','error'=>(string)($replay['error']??'The prior voice turn failed.'),'replayed'=>true]);exit;}
                chat_v121_emit(['type'=>'start','conversation_id'=>(int)($replay['conversation_id']??0),'user_message_id'=>(int)($replay['user_message_id']??0),'assistant_message_id'=>(int)($replay['assistant_message_id']??0),'replayed'=>true]);
                if(trim((string)($replay['answer']??''))!=='')chat_v121_emit(['type'=>'delta','delta'=>(string)$replay['answer'],'replayed'=>true]);
                chat_v121_emit(['type'=>'done','data'=>$replay+['replayed'=>true]]);exit;
            }
            throw new RuntimeException('That voice turn is already processing.');
        }
        $idempotencyClaimed=true;
    }
    agent_runtime_v125_trace('chat.turn.accepted',['user_id'=>$userId,'conversation_id'=>$conversationId,'idempotent'=>$idempotencyKey!=='' ]);

    if($conversationId<1){
        $workspaceId=artist_workspace_v181_scope_id($user);$stmt=$pdo->prepare('INSERT INTO chat_conversations (user_id,artist_workspace_id,title) VALUES (?,?,?)');$stmt->execute([$userId,$workspaceId?:null,mb_strimwidth($query,0,70,'…')]);$conversationId=(int)$pdo->lastInsertId();
    }elseif(!chat_v121_owned($pdo,$conversationId,$userId))throw new RuntimeException('Conversation not found.');

    $rawAgentContext=is_array($input['agent_context']??null)?$input['agent_context']:[];
    $rawAgentContext['conversation_id']=$conversationId;
    $agentContext=agent_surface_v131_enrich($user,'chat',$rawAgentContext);

    $historyStmt=$pdo->prepare('SELECT role,message FROM chat_messages WHERE conversation_id=? ORDER BY id DESC LIMIT 12');$historyStmt->execute([$conversationId]);$history=array_reverse($historyStmt->fetchAll());
    $stmt=$pdo->prepare('INSERT INTO chat_messages (conversation_id,user_id,role,message) VALUES (?,?,?,?)');$stmt->execute([$conversationId,$userId,'user',$query]);$userMessageId=(int)$pdo->lastInsertId();
    agent_brain_archive_and_parse($user,$conversationId,$userMessageId,'user',$query,'voice');

    $toolResult=agent_runtime_v125_span('chat.tools',static function() use($query,$user,$conversationId): array {
        $result=function_exists('release_v105_chat_tool')?release_v105_chat_tool($query,$user,$conversationId):['handled'=>false,'answer'=>'','stem_media'=>[],'media'=>[],'actions'=>[],'sources'=>[]];
        if(empty($result['handled']))$result=agent_tool_execute_query($query,$user,$conversationId);
        return $result;
    },['conversation_id'=>$conversationId,'user_id'=>$userId]);
    $context=empty($toolResult['handled'])?agent_runtime_v125_span('chat.context',static fn():array=>chat_v121_context($query,$user,$agentContext),['conversation_id'=>$conversationId,'user_id'=>$userId]):[];

    $stmt=$pdo->prepare("INSERT INTO chat_messages (conversation_id,user_id,role,message,context_json) VALUES (?,NULL,'assistant','','{}')");
    $stmt->execute([$conversationId]);$assistantMessageId=(int)$pdo->lastInsertId();

    if(session_status()===PHP_SESSION_ACTIVE)session_write_close();
    while(ob_get_level()>0)@ob_end_flush();
    chat_v121_emit(['type'=>'start','conversation_id'=>$conversationId,'user_message_id'=>$userMessageId,'assistant_message_id'=>$assistantMessageId]);

    $streamPartial=false;
    if(!empty($toolResult['handled'])){
        $answer=(string)$toolResult['answer'];
        if($answer!=='')chat_v121_emit(['type'=>'delta','delta'=>$answer]);
    }else{
        $streamResult=agent_runtime_v125_span('chat.ai_stream',static function() use($query,$history,$context,$user): array {
            return ai_v121_stream_chat_response($query,$history,$context,$user,static function(string $delta): void {
                if(connection_aborted())return;
                chat_v121_emit(['type'=>'delta','delta'=>$delta]);
            });
        },['conversation_id'=>$conversationId,'user_id'=>$userId]);
        $answer=trim((string)($streamResult['answer']??''));$streamPartial=!empty($streamResult['partial'])||connection_aborted();
        if($answer===''&&!connection_aborted()){
            $answer=chat_local_answer($query,$context);
            if($answer!=='')chat_v121_emit(['type'=>'delta','delta'=>$answer]);
        }
        if($answer===''&&connection_aborted())$answer='Interrupted.';
    }

    $publicSources=[];
    foreach($context as $item){
        $source=(string)($item['source']??'');if($source==='agent-context:v131')continue;
        $entry=['source'=>$source,'title'=>(string)($item['title']??'')];
        if(str_starts_with($source,'knowledge:')){
            $knowledgeId=(int)substr($source,strlen('knowledge:'));$knowledge=get_knowledge_item($knowledgeId);
            if($knowledge&&!empty($knowledge['file_path']))$entry['url']=url('/knowledge-file.php?id='.$knowledgeId);
        }
        $publicSources[]=$entry;
    }
    $toolSources=!empty($toolResult['sources'])&&is_array($toolResult['sources'])?$toolResult['sources']:[];$publicSources=array_merge($publicSources,$toolSources);
    $mediaLimit=track_is_playlist_request($query)?7:(track_is_next_request($query)?1:4);
    $answerMedia=track_media_from_answer($answer,$user,$mediaLimit);$queryMedia=track_media_suggestions($query,$user,$mediaLimit);
    $media=array_slice(track_merge_media_suggestions($answerMedia,$queryMedia),0,$mediaLimit);$playlistTitle=$media?track_playlist_title($query):'';
    $messageContext=[
        'sources'=>$publicSources,'media'=>$media,
        'stem_media'=>!empty($toolResult['stem_media'])&&is_array($toolResult['stem_media'])?$toolResult['stem_media']:[],
        'actions'=>!empty($toolResult['actions'])&&is_array($toolResult['actions'])?$toolResult['actions']:[],
        'playlist_title'=>$playlistTitle,'conversation_v131'=>true,'stream_partial'=>$streamPartial,'trace_id'=>agent_runtime_v125_trace_id(),
        'agent_context'=>$agentContext
    ];
    $contextJson=json_encode($messageContext,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    $stmt=$pdo->prepare('UPDATE chat_messages SET message=?,context_json=? WHERE id=? AND conversation_id=?');
    $stmt->execute([$answer,is_string($contextJson)?$contextJson:'{}',$assistantMessageId,$conversationId]);
    agent_brain_archive_and_parse($user,$conversationId,$assistantMessageId,'assistant',$answer,'voice');
    $pdo->prepare('UPDATE chat_conversations SET updated_at=NOW() WHERE id=?')->execute([$conversationId]);

    $done=[
        'ok'=>true,'conversation_id'=>$conversationId,'user_message_id'=>$userMessageId,'assistant_message_id'=>$assistantMessageId,
        'answer'=>$answer,'sources'=>$publicSources,'media'=>$media,'stem_media'=>$messageContext['stem_media'],'actions'=>$messageContext['actions'],
        'playlist_title'=>$playlistTitle,'input_mode'=>'voice','stream_partial'=>$streamPartial,'trace_id'=>agent_runtime_v125_trace_id()
    ];
    if($idempotencyClaimed&&$idempotencyKey!=='')agent_runtime_v125_idempotency_complete($idempotencyScope,$idempotencyKey,$done);
    agent_background_v125_enqueue('conversation-summary',['user_id'=>$userId,'conversation_id'=>$conversationId],'conversation-'.$userId.'-'.$conversationId);
    agent_background_v125_enqueue('memory-reconcile',['user_id'=>$userId],'memory-'.$userId,1);
    agent_runtime_v125_trace('chat.turn.completed',['user_id'=>$userId,'conversation_id'=>$conversationId,'assistant_message_id'=>$assistantMessageId,'partial'=>$streamPartial]);
    chat_v121_emit(['type'=>'done','data'=>$done]);
}catch(Throwable $e){
    if($assistantMessageId>0&&$pdo instanceof PDO){
        try{$pdo->prepare("DELETE FROM chat_messages WHERE id=? AND conversation_id=? AND message='' ")->execute([$assistantMessageId,$conversationId]);}catch(Throwable $cleanup){}
    }
    $publicError=ai_v100_safe_exception($e,'The voice conversation request could not be completed.');
    if($idempotencyClaimed&&$idempotencyScope!==''&&$idempotencyKey!==''){
        agent_runtime_v125_idempotency_complete($idempotencyScope,$idempotencyKey,['ok'=>false,'error'=>$publicError,'conversation_id'=>$conversationId,'assistant_message_id'=>$assistantMessageId,'trace_id'=>agent_runtime_v125_trace_id()]);
    }
    agent_runtime_v125_trace('chat.turn.error',['conversation_id'=>$conversationId,'assistant_message_id'=>$assistantMessageId,'error_class'=>get_class($e)]);
    chat_v121_emit(['type'=>'error','error'=>$publicError]);
}
